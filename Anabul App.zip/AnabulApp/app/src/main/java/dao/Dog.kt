package dao

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dogs")
data class Dog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val breed: String,
    val name: String,
    val age: Int,
)