package dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface DogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDog(dog: Dog)

    @Query("SELECT * FROM dogs")
    suspend fun getAllDogs(): List<Dog>

    @Query("SELECT * FROM dogs WHERE breed = :breed")
    suspend fun getDogsByBreed(breed: String): List<Dog>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDisease(disease: Disease)

    @Query("SELECT * FROM diseases")
    suspend fun getAllDiseases(): List<Disease>

    @Query("SELECT * FROM diseases WHERE dogId = :dogId")
    suspend fun getDiseasesByDogId(dogId: Long): List<Disease>
}