package desease

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName = "diseases", foreignKeys = [ForeignKey(entity = Dog::class, parentColumns = ["id"], childColumns = ["dogId"], onDelete = ForeignKey.CASCADE)])
data class Disease(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dogId: Long,
    val name: String,
    val description: String,
)