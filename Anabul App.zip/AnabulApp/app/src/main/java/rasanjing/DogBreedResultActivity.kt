package rasanjing

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.example.anabulapp.R
import com.example.anabulapp.models.DogBreed

class DogBreedResultActivity : AppCompatActivity() {
    private lateinit var breedImageView: ImageView
    private lateinit var breedNameTextView: TextView
    private lateinit var breedDescriptionTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dog_breed_result)

        breedImageView = findViewById(R.id.breedImageView)
        breedNameTextView = findViewById(R.id.breedNameTextView)
        breedDescriptionTextView = findViewById(R.id.breedDescriptionTextView)

        val dogBreed: DogBreed? = intent.getParcelableExtra(EXTRA_DOG_BREED)

        dogBreed?.let {
            breedImageView.setImageResource(it.imageResId)
            breedNameTextView.text = it.name
            breedDescriptionTextView.text = it.description
        }
    }

    companion object {
        const val EXTRA_DOG_BREED = "extra_dog_breed"
    }
}