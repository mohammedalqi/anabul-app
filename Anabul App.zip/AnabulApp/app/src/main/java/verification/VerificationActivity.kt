package verification

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.anabulapp.R

class VerificationActivity : AppCompatActivity() {
    private lateinit var verificationCodeEditText: EditText
    private lateinit var verifyButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verification)

        verificationCodeEditText = findViewById(R.id.verificationCodeEditText)
        verifyButton = findViewById(R.id.verifyButton)

        verifyButton.setOnClickListener {
            val verificationCode = verificationCodeEditText.text.toString()

            if (isVerificationCodeValid(verificationCode)) {

                startActivity(Intent(this, NextActivity::class.java))
                finish()
            } else {

                Toast.makeText(this, "Invalid verification code", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun isVerificationCodeValid(code: String): Boolean {
        return code.length == 6
    }
}